from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib import messages
from django.db.models import Count
from django.views.generic import DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import User, Follow
from .forms import CustomUserCreationForm, UserUpdateForm


class CustomLoginView(LoginView):
    template_name = 'accounts/login.html'
    redirect_authenticated_user = True
    
    def get_success_url(self):
        return '/feed/'


class CustomLogoutView(LogoutView):
    next_page = 'accounts:login'


def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('posts:feed')
    else:
        form = CustomUserCreationForm()
    return render(request, 'accounts/register.html', {'form': form})


class ProfileView(LoginRequiredMixin, DetailView):
    model = User
    template_name = 'accounts/profile.html'
    context_object_name = 'profile_user'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profile_user = self.get_object()
        context['is_following'] = Follow.objects.filter(
            follower=self.request.user, 
            following=profile_user
        ).exists()
        context['followers_list'] = Follow.objects.filter(following=profile_user).select_related('follower')
        context['following_list'] = Follow.objects.filter(follower=profile_user).select_related('following')
        return context


@login_required
def edit_profile(request):
    if request.method == 'POST':
        form = UserUpdateForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('accounts:profile', username=request.user.username)
    else:
        form = UserUpdateForm(instance=request.user)
    return render(request, 'accounts/edit_profile.html', {'form': form})


@login_required
def follow_user(request, username):
    user_to_follow = get_object_or_404(User, username=username)
    if user_to_follow != request.user:
        follow, created = Follow.objects.get_or_create(
            follower=request.user,
            following=user_to_follow
        )
        if created:
            user_to_follow.followers_count += 1
            request.user.following_count += 1
            user_to_follow.save()
            request.user.save()
    return redirect('accounts:profile', username=username)


@login_required
def unfollow_user(request, username):
    user_to_unfollow = get_object_or_404(User, username=username)
    follow = Follow.objects.filter(
        follower=request.user,
        following=user_to_unfollow
    ).first()
    if follow:
        follow.delete()
        user_to_unfollow.followers_count -= 1
        request.user.following_count -= 1
        user_to_unfollow.save()
        request.user.save()
    return redirect('accounts:profile', username=username)


def followers_list(request, username):
    user = get_object_or_404(User, username=username)
    followers = Follow.objects.filter(following=user).select_related('follower')
    return render(request, 'accounts/followers_list.html', {
        'user': user,
        'followers': followers
    })


def following_list(request, username):
    user = get_object_or_404(User, username=username)
    following = Follow.objects.filter(follower=user).select_related('following')
    return render(request, 'accounts/following_list.html', {
        'user': user,
        'following': following
    })
